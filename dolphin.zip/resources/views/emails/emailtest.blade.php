<!doctype html>
<html lang="en-US">
<head>
    <meta charset="text/html">
</head>
<body>
    
     Activate account
</body>
</html>