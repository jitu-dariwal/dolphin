<?php $__env->startComponent('mail::message'); ?>	
	<div>
		<p><?php echo e(__('Hi ').$name); ?></p>
		<p>Thank You for Register our site <b><?php echo e(env('APP_NAME')); ?></b> </p>
		<p>You can login on site <?php echo e(env('APP_URL')); ?>.</p>
		<br/>
		
		<p>Regards</p>
		<p><?php echo e(env('ADMIN_NAME')); ?></p>
		<p>If you have any concern please feel free to contact at <?php echo e(env('ADMIN_MAIL')); ?></p>
	</div>
<?php echo $__env->renderComponent(); ?>