<?php

return [
	'hint_questions' => [
		1 => 'DOB',
		2 => 'Pets Name',
		3 => 'Mother maiden name',
	],
];
